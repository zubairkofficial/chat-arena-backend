export class CreateConversationDto {}
