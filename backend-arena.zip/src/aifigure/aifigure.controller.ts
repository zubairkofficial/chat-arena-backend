import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { AifigureService } from './aifigure.service';
import { CreateAifigureDto } from './dto/create-aifigure.dto';
import { UpdateAifigureDto } from './dto/update-aifigure.dto';

@Controller('aifigure')
export class AifigureController {
  constructor(private readonly aifigureService: AifigureService) {}

  @Post()
  create(@Body() createAifigureDto: CreateAifigureDto) {
    return this.aifigureService.create(createAifigureDto);
  }

  @Get()
  findAll() {
    return this.aifigureService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.aifigureService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateAifigureDto: UpdateAifigureDto) {
    return this.aifigureService.update(+id, updateAifigureDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.aifigureService.remove(+id);
  }
}
