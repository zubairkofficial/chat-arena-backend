export class CreateAifigureDto {}
