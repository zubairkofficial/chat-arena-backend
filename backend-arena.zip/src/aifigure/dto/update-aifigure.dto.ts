import { PartialType } from '@nestjs/mapped-types';
import { CreateAifigureDto } from './create-aifigure.dto';

export class UpdateAifigureDto extends PartialType(CreateAifigureDto) {}
