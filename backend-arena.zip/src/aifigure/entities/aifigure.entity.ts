import { Arena } from 'src/arena/entities/arena.entity';
import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, OneToMany } from 'typeorm';

@Entity()
export class AIFigure {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column()
  role: string; // e.g., The Instructor, The Moderator, etc.

  @Column()
  prompt: string; 




  @OneToMany(() => Arena, (arena) => arena.aiFigures)
  arenas: Arena[];
}
