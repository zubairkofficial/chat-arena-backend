import { Module } from '@nestjs/common';
import { AifigureService } from './aifigure.service';
import { AifigureController } from './aifigure.controller';

@Module({
  controllers: [AifigureController],
  providers: [AifigureService],
})
export class AifigureModule {}
