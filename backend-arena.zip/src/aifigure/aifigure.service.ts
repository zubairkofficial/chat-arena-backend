import { Injectable } from '@nestjs/common';
import { CreateAifigureDto } from './dto/create-aifigure.dto';
import { UpdateAifigureDto } from './dto/update-aifigure.dto';

@Injectable()
export class AifigureService {
  create(createAifigureDto: CreateAifigureDto) {
    return 'This action adds a new aifigure';
  }

  findAll() {
    return `This action returns all aifigure`;
  }

  findOne(id: number) {
    return `This action returns a #${id} aifigure`;
  }

  update(id: number, updateAifigureDto: UpdateAifigureDto) {
    return `This action updates a #${id} aifigure`;
  }

  remove(id: number) {
    return `This action removes a #${id} aifigure`;
  }
}
