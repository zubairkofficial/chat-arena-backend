export class GoogleAuth {}
