export class CreateGoogleAuthDto {}
