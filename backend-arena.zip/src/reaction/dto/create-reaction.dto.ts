export class CreateReactionDto {}
