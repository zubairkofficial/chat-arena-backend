import { PartialType } from '@nestjs/mapped-types';
import { CreateArenaDto } from './create-arena.dto';

export class UpdateArenaDto extends PartialType(CreateArenaDto) {}
