export class CreateArenaDto {}
