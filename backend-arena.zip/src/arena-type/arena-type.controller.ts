import { Controller, Get, Post, Body, Param, Delete, Patch } from '@nestjs/common';
import { ArenaTypeService } from './arena-type.service';
import { ArenaTypeDto } from './dto/arena-type.dto';

@Controller('arena-types')
export class ArenaTypeController {
  constructor(private readonly arenaTypeService: ArenaTypeService) {}

  // Create one or multiple ArenaTypes
  @Post()
  async create(@Body() createArenaTypeDto: ArenaTypeDto.CreateArenaTypeDto | ArenaTypeDto.CreateArenaTypeDto[]) {
    if (Array.isArray(createArenaTypeDto)) {
      // If the request body is an array, handle multiple creation
      return this.arenaTypeService.createMany(createArenaTypeDto);
    }
    // Handle single creation
    return this.arenaTypeService.create(createArenaTypeDto);
  }

  @Get()
  async findAll() {
    return this.arenaTypeService.findAll();
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    return this.arenaTypeService.findOne(+id);  // Convert `id` from string to number
  }

  @Patch(':id')
  async update(
    @Param('id') id: string,
    @Body() updateArenaTypeDto: ArenaTypeDto.UpdateArenaTypeDto,
  ) {
    return this.arenaTypeService.update(+id, updateArenaTypeDto);
  }

  @Delete(':id')
  async remove(@Param('id') id: string) {
    return this.arenaTypeService.remove(+id);
  }
}
