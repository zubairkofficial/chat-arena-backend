import { Injectable } from '@nestjs/common';
import { DataSource, Repository } from 'typeorm';
import { ArenaType } from './entities/arena-type.entity';

@Injectable()
export class ArenaTypeRepository {
  private repository: Repository<ArenaType>;

  constructor(private readonly dataSource: DataSource) {
    this.repository = this.dataSource.getRepository(ArenaType);
  }

  // Delegate the `create` method to TypeORM's Repository
  async create(createArenaTypeDto: Partial<ArenaType>): Promise<ArenaType> {
    const newArenaType = this.repository.create(createArenaTypeDto);
    return this.repository.save(newArenaType);
  }

  // Delegate the `find` method to TypeORM's Repository
  async findAll(): Promise<ArenaType[]> {
    return this.repository.find();
  }

  // Delegate the `findOne` method to TypeORM's Repository
  async findOne(id: number): Promise<ArenaType> {
    return this.repository.findOne({ where: { id } });
  }

  // Delegate the `update` method
  async update(id: number, updateArenaTypeDto: Partial<ArenaType>): Promise<ArenaType> {
    const existingArenaType = await this.findOne(id);
    Object.assign(existingArenaType, updateArenaTypeDto);
    return this.repository.save(existingArenaType);
  }

  // Delegate the `delete` method to TypeORM's Repository
  async remove(id: number): Promise<void> {
    await this.repository.delete(id);
  }
}
