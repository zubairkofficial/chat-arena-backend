import { Injectable, NotFoundException } from '@nestjs/common';
import { ArenaTypeRepository } from './arena-type.repository';
import { ArenaTypeDto } from './dto/arena-type.dto';
import { ArenaType } from './entities/arena-type.entity';

@Injectable()
export class ArenaTypeService {
  constructor(private readonly arenaTypeRepository: ArenaTypeRepository) {}

  // Create a new ArenaType
  async create(createArenaTypeDto: ArenaTypeDto.CreateArenaTypeDto): Promise<ArenaType> {
    return this.arenaTypeRepository.create(createArenaTypeDto);
  }

    async createMany(createArenaTypeDtos: ArenaTypeDto.CreateArenaTypeDto[]): Promise<any> {
    const arenaTypes = createArenaTypeDtos.map(dto => this.arenaTypeRepository.create(dto));
    return arenaTypes;
  }

  // Get all ArenaTypes
  async findAll(): Promise<ArenaType[]> {
    return this.arenaTypeRepository.findAll();
  }

  // Get a specific ArenaType by ID
  async findOne(id: number): Promise<ArenaType> {
    const arenaType = await this.arenaTypeRepository.findOne(id);
    if (!arenaType) {
      throw new NotFoundException(`ArenaType with ID ${id} not found`);
    }
    return arenaType;
  }

  // Update an existing ArenaType
  async update(id: number, updateArenaTypeDto: ArenaTypeDto.UpdateArenaTypeDto): Promise<ArenaType> {
    return this.arenaTypeRepository.update(id, updateArenaTypeDto);
  }

  // Delete an ArenaType
  async remove(id: number): Promise<void> {
    return this.arenaTypeRepository.remove(id);
  }
}
