import { Arena } from 'src/arena/entities/arena.entity';
import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';

@Entity()
export class ArenaType {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;  // Name of the arena type

  @Column({ type: 'text' })
  description: string;  // Description of the arena type

  @Column({ type: 'text', nullable: true })
  prompt: string;  // Optional prompt or guidelines for the arena type

  @OneToMany(() => Arena, (arena) => arena.arenaType)
  arenas: Arena[];  // List of arenas associated with this type
}