export class CreateUserArenaDto {}
