export const DEFAULT_PAGE_LIMIT = 10;
export const DEFAULT_PAGE_OFFSET = 0;
export const DEFAULT_FILTER_INPUT_STRING = "{}";
export const DEFAULT_ORDER_BY_COLUMN = "id";
export const EXCLUDE_AUTH_GOOGLE_URL='user/auth-google'
export const EXCLUDE_REDIRECT_URL='user/redirect'


