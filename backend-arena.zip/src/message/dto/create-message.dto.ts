export class CreateMessageDto {}
