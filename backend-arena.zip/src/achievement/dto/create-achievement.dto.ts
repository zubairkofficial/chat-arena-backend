export class CreateAchievementDto {}
