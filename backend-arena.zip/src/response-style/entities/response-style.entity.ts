import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity()
export class ResponseStyle {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  style: string; // e.g., 'formal', 'sarcastic', 'supportive'
}
