export class CreateResponseStyleDto {}
